class Calc_RegisterValue:
    def __init__(self):
        #値と誤差許容率
        self.calc_list=[0,0]


    #計算式
    def calculation(self,value1,value2,scale,errorvalue):
        #値算出
        value=str(value1)+str(value2)
        value=int(value)


        #抵抗値計算
        register_value=value*(10**scale)
        self.errorvalue=errorvalue
        
        self.calc_list[0]=register_value
        self.calc_list[1]=errorvalue


    #計算結果表示
    def view_register(self):
        self.calculation(1,0,2,5)
        print(self.calc_list)


c=Calc_RegisterValue()
c.view_register()