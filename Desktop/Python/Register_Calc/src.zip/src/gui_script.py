import tkinter as tk


class Calc_RegisterValue:
    def __init__(self):
        #値と誤差許容率
        self.calc_list=[0,0]


    #計算式
    def calculation(self,r_list):
        #値算出
        value=str(r_list[0])+str(r_list[1])
        value=int(value)

        register_value=[None,None]
        #抵抗値計算
        register_value[0]=value*(10**r_list[2])
        if r_list[3]==10:
            register_value[1]=5
        
        elif r_list[3]==11:
            register_value[1]=10
        return register_value


    #計算結果表示
    def view_register(self):
        #self.calculation(1,0,2,5)
        print(self.calc_list)


class Window():
    def __init__(self):
        self.c=Calc_RegisterValue()
        self.root=tk.Tk()
        self.root.state("zoomed")
        self.root.title("抵抗計算機")
        self.displaySize=[]
        self.img_list=[]
        self.num_list=[None,None,None,None]
        self.num=None
        self.gosa=None
        self.var_result=tk.StringVar()
        self.var_result.set("抵抗の計算(4本ver)")


    #画像追加
    def image_adder(self):
        for i in range(0,12):
            self.img_list.append(tk.PhotoImage(file=r'img/'+str(i)+'.png'))


    #ディスプレイサイズ
    def displaysize_checker(self):
        
        self.displaySize.append(self.root.winfo_screenwidth())
        self.displaySize.append(self.root.winfo_screenheight())



    #抵抗値0
    def reg_0(self):
        self.num=0
    

    def reg_1(self):
        self.num=1
        self.gosa=1
    

    def reg_2(self):
        self.num=2
        self.gosa=2


    def reg_3(self):
        self.num=3

    
    def reg_4(self):
        self.num=4
        


    def reg_5(self):
        self.num=5
        self.gosa=0.5

    
    def reg_6(self):
        self.num=6
        self.gosa=0.25
    

    def reg_7(self):
        self.num=7
        self.gosa=0.10
    

    def reg_8(self):
        self.num=8
        self.gosa=0.05


    def reg_9(self):
        self.num=9

    
    def reg_10(self):
        self.gosa=10


    def reg_11(self):
        self.gosa=11
    

    def reg_list_appender(self):
        self.num_list[0]=self.num
        print(self.num_list)


    def reg_list_appender1(self):
        self.num_list[1]=self.num
        print(self.num_list)


    def reg_list_appender2(self):
        self.num_list[2]=self.num
        print(self.num_list)
    

    def reg_list_appender_gosa(self):
        self.num_list[3]=self.gosa
        print(self.num_list)


    def culc_result(self):
        print(self.num_list)
    
        for i in range(0,len(self.num_list)):
            if(self.num_list[i]==None):
                self.var_result.set("すべて入力してください")
                break

            else:
                result=self.c.calculation(self.num_list)

                if(result[0]<1000000 and result[0]>=1000):
                    result_str=str(int(result[0]/1000))+"kΩ, "+"誤差"+str(result[1])+"％"
        
                elif(result[0]>=1000000):
                    result_str=str(int(result[0]/1000000))+"MΩ, "+"誤差"+str(result[1])+"％"
        
                else:
                    result_str=str(result[0])+"Ω, "+"誤差"+str(result[1])+"％"

                self.var_result.set(result_str)
    

    def culc_clear(self):
        self.num_list=[None,None,None,None]

        self.var_result.set("消去しました")


    def view_button(self):
        self.root.update_idletasks()
        l=tk.Label(self.root,textvariable=self.var_result,font=("",45),anchor=tk.CENTER)
        l.grid(row=0,column=1,sticky=(tk.N, tk.S, tk.E, tk.W))

        button_0=tk.Button(self.root, image=self.img_list[0],text = "あ", width = self.displaySize[0]/12,command_=self.reg_0)
        button_0.grid(row=2,column=0,sticky=(tk.N, tk.S, tk.E, tk.W))
        button_1=tk.Button(self.root, image=self.img_list[1],text = "あ", width = self.displaySize[0]/12,command=self.reg_1)
        button_1.grid(row=2,column=1,sticky=(tk.N, tk.S, tk.E, tk.W))
        button_2=tk.Button(self.root, image=self.img_list[2],text = "あ", width = self.displaySize[0]/12,command=self.reg_2)
        button_2.grid(row=2,column=2,sticky=(tk.N, tk.S, tk.E, tk.W))
        button_3=tk.Button(self.root, image=self.img_list[3],text = "あ", width = self.displaySize[0]/12,command=self.reg_3)
        button_3.grid(row=3,column=0,sticky=(tk.N, tk.S, tk.E, tk.W))
        button_4=tk.Button(self.root, image=self.img_list[4],text = "あ", width = self.displaySize[0]/12,command=self.reg_4)
        button_4.grid(row=3,column=1,sticky=(tk.N, tk.S, tk.E, tk.W))
        button_5=tk.Button(self.root, image=self.img_list[5],text = "あ", width = self.displaySize[0]/12,command=self.reg_5)
        button_5.grid(row=3,column=2,sticky=(tk.N, tk.S, tk.E, tk.W))
        button_6=tk.Button(self.root,image=self.img_list[6],text = "あ", width = self.displaySize[0]/12,command=self.reg_6)
        button_6.grid(row=4,column=0,sticky=(tk.N, tk.S, tk.E, tk.W))
        button_7=tk.Button(self.root, image=self.img_list[7],text = "あ", width = self.displaySize[0]/12,command=self.reg_7)
        button_7.grid(row=4,column=1,sticky=(tk.N, tk.S, tk.E, tk.W))
        button_8=tk.Button(self.root, image=self.img_list[8],text = "あ", width = self.displaySize[0]/12,command=self.reg_8)
        button_8.grid(row=4,column=2,sticky=(tk.N, tk.S, tk.E, tk.W))
        button_9=tk.Button(self.root, image=self.img_list[9],text = "あ", width = self.displaySize[0]/12,command=self.reg_9)
        button_9.grid(row=5,column=0,sticky=(tk.N, tk.S, tk.E, tk.W))
        button_10=tk.Button(self.root, image=self.img_list[10],text = "あ", width = self.displaySize[0]/12,command=self.reg_10)
        button_10.grid(row=5,column=1,sticky=(tk.N, tk.S, tk.E, tk.W))
        button_11=tk.Button(self.root, image=self.img_list[11],text = "あ", width = self.displaySize[0]/12,command=self.reg_11)
        button_11.grid(row=5,column=2,sticky=(tk.N, tk.S, tk.E, tk.W))


        #ボタン類
        button_12=tk.Button(self.root,text = "1列目",font=("",33), width =5,command=self.reg_list_appender)
        button_12.grid(row=2,column=3,sticky=(tk.N, tk.S, tk.E, tk.W))
        button_13=tk.Button(self.root,text = "2列目", font=("",33),width =5,command=self.reg_list_appender1)
        button_13.grid(row=3,column=3,sticky=(tk.N, tk.S, tk.E, tk.W))
        button_14=tk.Button(self.root,text = "3列目",font=("",33), width =5,command=self.reg_list_appender2)
        button_14.grid(row=4,column=3,sticky=(tk.N, tk.S, tk.E, tk.W))
        button_16=tk.Button(self.root,text = "誤差",font=("",33),width =5,command=self.reg_list_appender_gosa)
        button_16.grid(row=5,column=3,sticky=(tk.N, tk.S, tk.E, tk.W))
        button_E=tk.Button(self.root,text = "Ent",font=("",33), width =5,command_=self.culc_result)
        button_E.grid(row=1,column=3,sticky=(tk.N, tk.S, tk.E, tk.W))
        button_E=tk.Button(self.root,text = "クリア",font=("",33), width =5,command_=self.culc_clear)
        button_E.grid(row=0,column=3,sticky=(tk.N, tk.S, tk.E, tk.W))
        self.root.grid_rowconfigure(1, weight=1)
        self.root.grid_rowconfigure(2, weight=1)
        self.root.grid_rowconfigure(3, weight=1)
        self.root.grid_rowconfigure(4, weight=1)
        self.root.grid_rowconfigure(5, weight=1)
        self.root.grid_columnconfigure(0, weight=1)
        self.root.grid_columnconfigure(1, weight=1)
        self.root.grid_columnconfigure(2, weight=1)
        self.root.grid_columnconfigure(3, weight=1)


    def looper(self):
        self.displaysize_checker()
        self.image_adder()
        self.view_button()
        self.root.mainloop()




w=Window()
w.looper()
